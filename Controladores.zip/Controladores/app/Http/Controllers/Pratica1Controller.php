<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Pratica1Controller extends Controller
{
    //
    public function produtos(){
        return view('produtos');
    }

    public function getNome($nome){
        return "Olá $nome , seja bem vindo ao Laravel";
    }

    public function multiplicacao($n1,$n2){
        return "A multiplicação entre $n1 e $n2 é " . ($n1 * $n2);
    }
}
