<?php

namespace App\Http\Controllers;

use App\Models\Autor;
use App\Models\Isbn;
use Illuminate\Http\Request;
use App\Models\Livro;
use App\Models\Editora;
use Illuminate\Support\Facades\DB;

class LivroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        //$livros = Livro::all();
        $livros = Livro::paginate(2);
        return view('livroBootstrap.index')-> with('livros',$livros);
    }

    public function indexExcluido(){
        $livros = Livro::onlyTrashed()->paginate(2);
        return view ('livroBootstrap.indexExcluido')->with('livros',$livros);
    }

    public function indexTodos(){
        $livros = Livro::withTrashed()->paginate(2);
        return view ('livroBootstrap.indexTodos')->with('livros',$livros);
    }
    public function index2()
    {
        //
        return Livro::with(['isbn','editora'])->get();
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $editoras = Editora::orderBy('nome')->get();
        return view('livroBootstrap.create')->with('editoras',$editoras);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $livro = new Livro();
        $livro->titulo= $request->nome;
        
        $livro->anoPublicacao= $request->ano;

        $isbn = new Isbn();
        $isbn -> numero = $request->isbn;
        $isbn->save();

        $idEditora = $request->editora;
        $editora = Editora::find($idEditora);

        $livro->isbn()->associate($isbn);
        $livro->editora()->associate($editora);

        $livro->save();
        return redirect()->route('livro.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $livro = Livro::find($id);
        $autores = Autor::orderBy('nome')->get();
        return view ('livroBootstrap.show')
            ->with('livro',$livro)
            ->with('autores', $autores);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $livro = Livro::find($id);
        return view ('livroBootstrap.edit')->with('livro',$livro);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $livro = Livro::find($id);
        $isbn = Isbn::where ('id',$livro->isbn_id)->get()[0];
        $isbn->numero = $request->isbn;
        $isbn->update();
        
        
        $livro -> titulo = $request -> nome;
        $livro -> anoPublicacao = $request -> ano;
        $livro -> update();
        return redirect()->route('livro.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $livro = Livro::find($id);
        $livro ->delete();
        return redirect()->route('livro.index');
    }

    public function pesquisa(Request $request){
        $titulo = $request -> pesquisa;
        $pesquisa = "%$titulo%";
        
        //$livros = Livro::where('nome','like',$pesquisa)->get();
        
         $livros = Livro::where('titulo','like',$pesquisa)
                        -> orWhere('anoPublicacao','=',$titulo)
                        -> orWhere('autor','like',$pesquisa)
                        ->get();
            
                return view('livroBootstrap.index')-> with('livros',$livros);
    }

    public function associarLivroAutor(Request $request){
        $livro = Livro::find($request->id);

        if(isset($livro)){
            $livro->autor()->attach($request->autores);
        }
    }

    public function desassociarLivroAutor(Request $request){
        $livro = Livro::find($request->idLivro);
        if(isset($livro)){
            $livro->autor()->detach($request->idAutor);
        }
    }


    //Restaura um registro excluído

    public function restore($id, $rota){
        $livro = Livro::onlyTrashed()->find($id);
        $livro->restore();

        switch($rota){
            case 1:
                return redirect()->route('livroBootstrap.indexExcluido');
                break;
            case 2:
                return redirect()-> route('livroBootstrap.indexTodos');
                break;

        }
    }

    public function forceDestroy($id, $rota){
        $livro = Livro::onlyTrashed()->find($id);
        $livro-> forceDelete();
        

        switch($rota){
            case 1:
                return redirect()->route('livroBootstrap.indexExcluido')->with('livros',$livro);
                break;
            case 2:
                return redirect()-> route('livroBootstrap.indexTodos');
                break;

        }
    }
}
