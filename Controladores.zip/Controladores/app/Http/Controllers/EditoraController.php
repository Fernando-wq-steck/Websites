<?php

namespace App\Http\Controllers;

use App\Models\Editora;
use Illuminate\Http\Request;

class EditoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $editoras = Editora::all();
        return view('editoraBootstrap.principal')-> with('editoras',$editoras);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $editoras = Editora::orderBy('nome')->get();
        return view('editoraBootstrap.create')->with('editoras',$editoras);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
      
        $editora = new Editora();
        $editora->nome = $request->nome;
        $editora->save();
        return redirect()->route('editora.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $editora = Editora::find($id);
        return view ('editora.edit')->with('editora',$editora);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $editora = Editora::find($id);
        $editora -> nome = $request -> nome;
        
        $editora -> update();
        return redirect()->route('editora.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        $editora = Editora::find($id);
        $editora ->delete();
        return redirect()->route('editora.index');
    }

    public function pesquisa(Request $request){
        $nome = $request -> pesquisa;
        $pesquisa = "%$nome%";
        
        //$livros = Livro::where('nome','like',$pesquisa)->get();
        
         $editora = Editora::where('nome','like',$pesquisa)->get();
            
                //return view('editoraBootstrap.principal')-> with('nome',$editora);
    }
}
